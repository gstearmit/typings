"use strict";
/* * * ./app/slider/model/slider.ts * * */
var BigSlider = (function () {
    function BigSlider(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return BigSlider;
}());
exports.BigSlider = BigSlider;
//# sourceMappingURL=big-slider.js.map