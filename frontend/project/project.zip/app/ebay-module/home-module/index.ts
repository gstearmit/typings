/**
 * This barrel file provides the export for the homes loaded homeComponent.
 */
export * from './component/home/home.component';
