/**
 * This barrel file provides the export for the ebay loaded ebayComponent.
 */
export * from './portal/amazon.component';
