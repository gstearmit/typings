"use strict";
/* * * ./app/home/dhgate-box/model/dhgate-box.ts * * */
var DhgateBox = (function () {
    function DhgateBox(listimage, slider) {
        this.listimage = listimage;
        this.slider = slider;
    }
    return DhgateBox;
}());
exports.DhgateBox = DhgateBox;
//# sourceMappingURL=dhgate-box.js.map