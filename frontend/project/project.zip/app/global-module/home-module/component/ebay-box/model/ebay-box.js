"use strict";
/* * * ./app/home/amaxon-box/model/amazon-box.ts * * */
var EbayBox = (function () {
    function EbayBox(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return EbayBox;
}());
exports.EbayBox = EbayBox;
//# sourceMappingURL=ebay-box.js.map