import { Component,OnInit } from '@angular/core';
@Component({
	moduleId: module.id,
	selector: 'mobile-app',
	templateUrl: 'home.component.html'
})
export class HomeComponent  {
	onScroll () {
        console.log('scrolled!!')
    }
}