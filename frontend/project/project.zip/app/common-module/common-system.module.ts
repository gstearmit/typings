import { NgModule } from '@angular/core';
import { LeftMenuComponent } from './component/left-menu/left-menu.component';

@NgModule({
	imports: [

	],
	providers: [

	],
	declarations: [
		LeftMenuComponent
	],
	exports: [
		LeftMenuComponent
	]
})
export class CommonSystemModule { }


