/**
 * This barrel file provides the export for the homes loaded homeComponent.
 */
export * from './ebay.component';
