"use strict";
/* * * ./app/slider/model/slider.ts * * */
var BuyFrom = (function () {
    function BuyFrom(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return BuyFrom;
}());
exports.BuyFrom = BuyFrom;
//# sourceMappingURL=buy-from.js.map