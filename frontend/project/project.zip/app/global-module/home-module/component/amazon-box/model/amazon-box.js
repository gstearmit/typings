"use strict";
/* * * ./app/home/amaxon-box/model/amazon-box.ts * * */
var AmazonBox = (function () {
    function AmazonBox(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return AmazonBox;
}());
exports.AmazonBox = AmazonBox;
//# sourceMappingURL=amazon-box.js.map