import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mobile-app',
    templateUrl: 'error.component.html',
    providers: [
        // TranslateService
    ],
})
export class ErrorComponent implements OnInit {
    constructor() { }

    ngOnInit() {

    }
}