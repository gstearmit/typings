import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: `internal-server.component.html`
})

export class InternalServerComponent implements OnInit {
    ngOnInit() {}
}