// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'amazon-nav',
    templateUrl: 'amazon-nav.component.html'
})
// Component class implementing OnInit
export class AmazonNavComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
