import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mobile-app',
    templateUrl: 'ebay.component.html',
    providers: [
        // TranslateService
    ],
})
export class EbayComponent implements OnInit {
    constructor() { }

    ngOnInit() {

    }
}