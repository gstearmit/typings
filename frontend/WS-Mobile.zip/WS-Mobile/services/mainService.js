/**
 * Created by nktquan@gmail.com on 4/14/16
 */

$.getScript('services/authService.js');
$.getScript('services/amazonService.js');
$.getScript('services/dhgateService.js');
$.getScript('services/ebayService.js');
$.getScript('services/weshopService.js');