// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'ebay-foot-cate',
    templateUrl: 'ebay-foot-cate.component.html'
})
// Component class implementing OnInit
export class EbayFootcateComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
