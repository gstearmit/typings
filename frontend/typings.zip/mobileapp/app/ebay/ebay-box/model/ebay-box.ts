/* * * ./app/home/amaxon-box/model/amazon-box.ts * * */
export class EbayBox {
    constructor(
        public listimage: {},
        public slider: {}
    ){}
}