"use strict";
/* * * ./app/slider/model/slider.ts * * */
var Slider = (function () {
    function Slider(src, title) {
        this.src = src;
        this.title = title;
    }
    return Slider;
}());
exports.Slider = Slider;
//# sourceMappingURL=slider.js.map