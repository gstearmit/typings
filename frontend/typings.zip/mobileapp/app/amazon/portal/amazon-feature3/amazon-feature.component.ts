// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'amazon-feature3',
    templateUrl: 'amazon-feature.component.html'
})
// Component class implementing OnInit
export class AmazonFeature3Component implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
