"use strict";
/* * * ./app/home/recently-view/model/recentlyview.ts * * */
var Recentlyview = (function () {
    function Recentlyview(id, src, title, price, currency, sale) {
        this.id = id;
        this.src = src;
        this.title = title;
        this.price = price;
        this.currency = currency;
        this.sale = sale;
    }
    return Recentlyview;
}());
exports.Recentlyview = Recentlyview;
//# sourceMappingURL=recentlyview.js.map