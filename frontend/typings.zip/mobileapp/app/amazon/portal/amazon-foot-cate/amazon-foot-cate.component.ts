// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'amazon-foot-cate',
    templateUrl: 'amazon-foot-cate.component.html'
})
// Component class implementing OnInit
export class AmazonFootcateComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
