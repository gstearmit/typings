// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'ebay-nav',
    templateUrl: 'ebay-nav.component.html'
})
// Component class implementing OnInit
export class EbayNavComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
