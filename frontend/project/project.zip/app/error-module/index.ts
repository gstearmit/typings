/**
 * This barrel file provides the export for the homes loaded homeComponent.
 */
export * from './component/not-found/not-found.component';
