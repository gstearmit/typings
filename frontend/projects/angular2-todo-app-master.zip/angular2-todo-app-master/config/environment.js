// Angular-CLI server configuration
// Unrelated to environment.dev|prod.ts

/* jshint node: true */

module.exports = function(environment) {
  return {
    environment: environment,
    baseURL: '/',
    locationType: 'auto'
  };
};

