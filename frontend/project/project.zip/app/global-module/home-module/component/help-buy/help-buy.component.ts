import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'help-buy',
    templateUrl: `help-buy.component.html`
})

export class HelpBuyComponent implements OnInit {
    ngOnInit() {}
}