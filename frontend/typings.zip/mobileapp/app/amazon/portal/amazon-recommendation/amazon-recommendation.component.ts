// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'amazon-recommendation',
    templateUrl: 'amazon-recommendation.component.html'
})
// Component class implementing OnInit
export class AmazonRecommendationComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
