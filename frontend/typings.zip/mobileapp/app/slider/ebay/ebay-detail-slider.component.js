"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var slider_service_1 = require('./services/slider.service');
var EbayDetailSliderComponent = (function () {
    function EbayDetailSliderComponent(ebaySliderService) {
        this.ebaySliderService = ebaySliderService;
        this.ebayDetailSlider = {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            loop: true,
            autoplay: 1000
        };
        this.dataSlider = this.ebaySliderService.getEbayDetailImage();
    }
    EbayDetailSliderComponent.prototype.ngOnInit = function () {
        this.dataSlider = this.ebaySliderService.getEbayDetailImage();
    };
    EbayDetailSliderComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'ebay-detail-slider',
            templateUrl: "ebay-detail-slider.component.html"
        }), 
        __metadata('design:paramtypes', [slider_service_1.EbayDetailImageService])
    ], EbayDetailSliderComponent);
    return EbayDetailSliderComponent;
}());
exports.EbayDetailSliderComponent = EbayDetailSliderComponent;
//# sourceMappingURL=ebay-detail-slider.component.js.map