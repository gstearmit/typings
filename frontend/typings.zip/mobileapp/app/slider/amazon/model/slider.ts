/* * * ./app/slider/model/slider.ts * * */
export class Slider {
    constructor(
        public src: string, 
        public title:string
        ){}
}