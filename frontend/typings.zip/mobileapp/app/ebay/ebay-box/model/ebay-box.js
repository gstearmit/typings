"use strict";
/* * * ./app/home/amaxon-box/model/amazon-box.ts * * */
var EbayBox = (function () {
    function EbayBox(listimage, slider) {
        this.listimage = listimage;
        this.slider = slider;
    }
    return EbayBox;
}());
exports.EbayBox = EbayBox;
//# sourceMappingURL=ebay-box.js.map