"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var angular2_infinite_scroll_1 = require('angular2-infinite-scroll');
var angular2_useful_swiper_1 = require('angular2-useful-swiper');
var amazon_component_1 = require('./portal/amazon.component');
var header_amazon_component_1 = require('../header/amazon/header-amazon.component');
var amazon_nav_component_1 = require('./portal/amazon-nav/amazon-nav.component');
var amazon_banner_component_1 = require('./portal/amazon-banner/amazon-banner.component');
var amazon_hotdeal_component_1 = require('./portal/amazon-hotdeal/amazon-hotdeal.component');
var amazon_feature_component_1 = require('./portal/amazon-feature1/amazon-feature.component');
var amazon_feature_component_2 = require('./portal/amazon-feature2/amazon-feature.component');
var amazon_feature_component_3 = require('./portal/amazon-feature3/amazon-feature.component');
var amazon_recommendation_component_1 = require('./portal/amazon-recommendation/amazon-recommendation.component');
var amazon_foot_cate_component_1 = require('./portal/amazon-foot-cate/amazon-foot-cate.component');
var browser_component_1 = require('./browser/browser.component');
var detail_component_1 = require('./detail/detail.component');
var amazon_detail_slider_component_1 = require('../slider/amazon/amazon-detail-slider.component');
var slider_service_1 = require('../slider/amazon/services/slider.service');
var amazon_routes_1 = require('./amazon.routes');
var AmazonModule = (function () {
    function AmazonModule() {
    }
    AmazonModule = __decorate([
        core_1.NgModule({
            imports: [amazon_routes_1.amazonRoutes, platform_browser_1.BrowserModule, angular2_infinite_scroll_1.InfiniteScrollModule, angular2_useful_swiper_1.SwiperModule],
            declarations: [
                amazon_component_1.AmazonComponent,
                amazon_nav_component_1.AmazonNavComponent,
                amazon_banner_component_1.AmazonBannerComponent,
                amazon_hotdeal_component_1.AmazonHotdealComponent,
                amazon_feature_component_1.AmazonFeature1Component,
                amazon_feature_component_2.AmazonFeature2Component,
                amazon_feature_component_3.AmazonFeature3Component,
                amazon_recommendation_component_1.AmazonRecommendationComponent,
                amazon_foot_cate_component_1.AmazonFootcateComponent,
                header_amazon_component_1.HeaderAmazonComponent,
                browser_component_1.AmazonBrowserComponent,
                detail_component_1.AmazonDetailComponent,
                amazon_detail_slider_component_1.AmazonDetailSliderComponent,
            ],
            exports: [
                amazon_component_1.AmazonComponent,
                amazon_nav_component_1.AmazonNavComponent,
                amazon_banner_component_1.AmazonBannerComponent,
                amazon_hotdeal_component_1.AmazonHotdealComponent,
                amazon_feature_component_1.AmazonFeature1Component,
                amazon_feature_component_2.AmazonFeature2Component,
                amazon_feature_component_3.AmazonFeature3Component,
                amazon_recommendation_component_1.AmazonRecommendationComponent,
                amazon_foot_cate_component_1.AmazonFootcateComponent,
                header_amazon_component_1.HeaderAmazonComponent,
                browser_component_1.AmazonBrowserComponent,
                detail_component_1.AmazonDetailComponent,
                amazon_detail_slider_component_1.AmazonDetailSliderComponent,
                angular2_useful_swiper_1.SwiperModule
            ],
            providers: [
                slider_service_1.AmazonDetailImageService
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], AmazonModule);
    return AmazonModule;
}());
exports.AmazonModule = AmazonModule;
//# sourceMappingURL=amazon.module.js.map