import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'header-ebay',
    templateUrl: `header-ebay.component.html`
})

export class HeaderEbayComponent implements OnInit {
    ngOnInit() {}
}