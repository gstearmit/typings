// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'amazon-hotdeal',
    templateUrl: 'amazon-hotdeal.component.html'
})
// Component class implementing OnInit
export class AmazonHotdealComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}