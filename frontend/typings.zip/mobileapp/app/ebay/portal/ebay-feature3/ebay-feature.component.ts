// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'ebay-feature3',
    templateUrl: 'ebay-feature.component.html'
})
// Component class implementing OnInit
export class EbayFeature3Component implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
