"use strict";
/* * * ./app/slider/model/slider.ts * * */
var Slider = (function () {
    function Slider(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return Slider;
}());
exports.Slider = Slider;
//# sourceMappingURL=slider.js.map