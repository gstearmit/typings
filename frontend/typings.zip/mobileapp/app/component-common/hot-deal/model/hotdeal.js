"use strict";
/* * * ./app/home/hot-deal/model/hotdeal.ts * * */
var Hotdeal = (function () {
    function Hotdeal(status, success, messages, data) {
        this.status = status;
        this.success = success;
        this.messages = messages;
        this.data = data;
    }
    return Hotdeal;
}());
exports.Hotdeal = Hotdeal;
//# sourceMappingURL=hotdeal.js.map