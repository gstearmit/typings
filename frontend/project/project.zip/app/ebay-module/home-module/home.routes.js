"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('./component/home/home.component');
var routes = [
    {
        path: '',
        component: home_component_1.HomeComponent,
    }
];
exports.homeRoutes = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=home.routes.js.map