// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    templateUrl: 'ebay.component.html'
})
// Component class implementing OnInit
export class EbayComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}