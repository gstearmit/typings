// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'ebay-feature1',
    templateUrl: 'ebay-feature.component.html'
})
// Component class implementing OnInit
export class EbayFeature1Component implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
