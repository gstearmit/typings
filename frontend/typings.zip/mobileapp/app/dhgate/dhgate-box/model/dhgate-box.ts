/* * * ./app/home/dhgate-box/model/dhgate-box.ts * * */
export class DhgateBox {
    constructor(
        public listimage: {},
        public slider: {}
    ){}
}