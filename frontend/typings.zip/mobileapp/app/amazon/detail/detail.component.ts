// Imports
import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    templateUrl: 'detail.component.html'
})
// Component class implementing OnInit
export class AmazonDetailComponent implements OnInit {
    // Private property for binding
    // Load data ones componet is ready
    ngOnInit() {}
}
